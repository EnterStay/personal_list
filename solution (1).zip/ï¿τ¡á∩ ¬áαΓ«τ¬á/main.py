from flask import Flask, render_template
import json
from random import randrange

app = Flask(__name__)


@app.route('/member')
def login():
    with open('templates\members.json', encoding='utf-8') as f:
        data = json.load(f)
        ind = randrange(len(data))
        member = data[ind]
        member['list'] = ', '.join(sorted(member['list']))
    return render_template('table.html', data=member)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')